# Discord-Token-Generator

![s](https://cdn.discordapp.com/attachments/887757784337252413/954385886341111899/gen.png)

# INFO
- This is a Simple Discord Token Generator which creates verified discord accounts 
- These accounts are good for selling for raiding
- Uses HCAPTCHA Bypass

# Requirements 
- put the hcaptcha.py file inside the project folder, check my hcaptcha bypass repo for the file
- httpx https://pypi.org/project/httpx/
- Rotating Proxies

# INSTALL
- click install.bat and wating press any key to continue...
- add proxies inside "all://": "http://username:pass@ip:port" or "all://": "http://ip:port" depending on your proxies authentication
- add proxies inside hcaptcha bypass too >  proxy="username:password@ip:port" or proxy="ip:port"

# USAGE
- type python main.py or node index.js
- waiting and Enjoin!!

# Ty for Using my Tool!
